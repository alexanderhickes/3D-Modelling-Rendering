#include "Cube.h"
#include <iostream>
#include "RayTracingFramework\Ray.h"
#include "Cube.h"
#include "RayTracingFramework\VirtualObject\IVirtualObject.h"

using namespace std;

RayTracingFramework::Cube::Cube(glm::vec4 p, glm::vec4 q)
	:p(p),
	 q(q),
	 topPlane(q, glm::vec4(0, 1, 0, 0)), 
     bottomPane(p, glm:vec4(0, -1, 0, 0)),
     rightPlane(q, glm:vec4(1, 0, 0, 0)),
     leftPlane(p, glm:vec4(-1, 0, 0, 0)),
     frontPlane(q, glm:vec4(0, 0, 1, 0)),
     backPlane(q, glm:vec4(0, 0, -1, 0)),
{
	;
}

int faces()
{
	return 0;
}

void 
bool RayTracingFramework::Cube::testLocalCollision(RayTracingFramework::Ray& ray) {
	//0. Transform origin and direction coordinates to local coordinates (Ray is described in World coordinates):
	glm::vec4 origin_local = owner->getFromWorldToObjectCoordinates()*ray.origin_InWorldCoords;
	glm::vec4 direction_local = owner->getFromWorldToObjectCoordinates()*ray.direction_InWorldCoords;
	//1. Compute intersection with plane (compute collision point and normal). 
	glm::vec4 collision_Point, collision_Normal;
	float t;
	if (testRayCubeCollision(origin_local, direction_local
		, t, collision_Point, collision_Normal)) {
		//2. Intersection! --> Add it to the result (ray).
		Ray::Intersection i1;
		i1.t_distance = t;
		i1.collidingObjectID = owner->getID();
		i1.collisionPoint_InObjectCoords = collision_Point;
		i1.collisionNormalVector_InObjectCoords = collision_Normal;
		//3. To transform from local (object) coords to world coordinates 
		i1.fromObjectToWorldCoords = owner->getFromObjectToWorldCoordinates();
		ray.addIntersection(i1);
		return true;
	}
	return false;

}

int RayTracingFramework::Cube::testRayCubeCollision(glm::vec4 origin, glm::vec4 direction
	, float& t, glm::vec4& col_P, glm::vec4& col_N)
{
	//create planes:
	
	

	

	//Check constraints
	if (p.x < x && q.x > x && p.y < y && q.y > y && p.z < z && q.z > z)
	{

	}
	
	if ()//Plane is parallel to ray (intersection at infinity)
		return false;				  // Intersection at infinite
	else {
		//Common intersection: Compute using parametric & implicit equations (as in slides), and fill in our "Output parameters t, col_P and col_N.
		t = ();
		col_P = origin + t*direction;	//According to parametric equation: P(t)=P0 + t* direction
		col_N = this->N;				//Normal of the plane
		return true;
	}
}


