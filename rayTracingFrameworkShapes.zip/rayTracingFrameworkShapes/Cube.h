#pragma once
#include <RayTracingFramework\RayTracingPrerequisites.h>
#include <RayTracingFramework\GeometricPrimitives\IGeometry.h>

namespace RayTracingFramework {

	class Cube : public IGeometry
	{
		
		glm::vec4 p, q; //min x, y, z. //max x, y, z.
		RayTracingFramework::Plane topPlane, bottomPlane, frontPlane, backPlane, leftPlane, rightPlane;

	public:
		Cube(glm::vec4 p, glm::vec4 q);
		virtual bool testLocalCollision(RayTracingFramework::Ray& ray);
		int testRayCubeCollision(glm::vec4 origin, glm::vec4 direction
			, float& t, glm::vec4& col_P, glm::vec4& col_N);
	};

};


